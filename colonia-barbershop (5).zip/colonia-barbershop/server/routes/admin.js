// server/routes/admin.js
const express = require("express");
const bcrypt = require("bcryptjs");
const db = require("../db");
const { signAdminToken, requireAdmin } = require("../auth");
const { loginLimiter } = require("../middleware/rateLimiter");
const { getAvailableSlots } = require("../utils/slots");
const { generateConfirmationCode } = require("../utils/confirmationCode");
const { isNonEmptyString, isValidDate, isValidTime, isValidPhone, isValidEmail } = require("../middleware/validate");

const router = express.Router();

// POST /api/admin/login
router.post("/login", loginLimiter, (req, res) => {
  const { username, password } = req.body || {};
  const validUser = username === process.env.ADMIN_USERNAME;
  const validPass =
    process.env.ADMIN_PASSWORD_HASH && password
      ? bcrypt.compareSync(password, process.env.ADMIN_PASSWORD_HASH)
      : false;

  if (!validUser || !validPass) return res.status(401).json({ error: "Invalid username or password" });

  res.json({ token: signAdminToken() });
});

router.use(requireAdmin);

// GET /api/admin/overview — quick stats for the dashboard header
router.get("/overview", (req, res) => {
  const todayStr = new Date().toISOString().slice(0, 10);
  const weekAgo = new Date(Date.now() - 7 * 86400000).toISOString().slice(0, 10);

  const todayCount = db
    .prepare("SELECT COUNT(*) c FROM bookings WHERE date = ? AND status NOT IN ('cancelled')")
    .get(todayStr).c;
  const upcomingCount = db
    .prepare("SELECT COUNT(*) c FROM bookings WHERE date >= ? AND status NOT IN ('cancelled','completed','no_show')")
    .get(todayStr).c;
  const newLeads = db.prepare("SELECT COUNT(*) c FROM leads WHERE status = 'new'").get().c;
  const last7DaysBookings = db
    .prepare("SELECT COUNT(*) c FROM bookings WHERE date >= ? AND status NOT IN ('cancelled')")
    .get(weekAgo).c;

  res.json({ todayCount, upcomingCount, newLeads, last7DaysBookings });
});

// GET /api/admin/barbers — for the "assign to" dropdown when logging a manual booking
router.get("/barbers", (req, res) => {
  res.json(db.prepare("SELECT * FROM barbers WHERE active = 1 ORDER BY sort_order").all());
});

// POST /api/admin/bookings — log a phone call or walk-in into the SAME schedule
// the website reads from. This is what keeps a 4PM phone booking from colliding
// with a 4PM website booking: both end up as rows in the same `bookings` table,
// so getAvailableSlots() (and the public widget) sees the full picture either way.
router.post("/bookings", (req, res) => {
  const {
    customer_name,
    customer_phone,
    customer_email,
    service_id,
    barber_id, // optional — leave unset if it doesn't matter who cuts
    date,
    time,
    notes,
    source, // "phone" | "walk_in" | "other" — defaults to "phone"
    force, // true = log it even though a conflict was reported
  } = req.body || {};

  if (!isNonEmptyString(customer_name, 100)) return res.status(400).json({ error: "Name is required" });
  if (!isValidPhone(customer_phone)) return res.status(400).json({ error: "Valid phone number is required" });
  if (customer_email && !isValidEmail(customer_email)) return res.status(400).json({ error: "Email looks invalid" });
  if (!service_id) return res.status(400).json({ error: "Service is required" });
  if (!isValidDate(date)) return res.status(400).json({ error: "Date is invalid" });
  if (!isValidTime(time)) return res.status(400).json({ error: "Time is invalid" });

  const service = db.prepare("SELECT * FROM services WHERE id = ? AND active = 1").get(service_id);
  if (!service) return res.status(404).json({ error: "Unknown service" });

  let barber = null;
  if (barber_id) {
    barber = db.prepare("SELECT * FROM barbers WHERE id = ? AND active = 1").get(barber_id);
    if (!barber) return res.status(404).json({ error: "Unknown barber" });
  }

  const isOpen = getAvailableSlots({
    date,
    durationMinutes: service.duration_minutes,
    barberId: barber_id ? Number(barber_id) : null,
  }).includes(time);

  if (!isOpen && !force) {
    return res.status(409).json({
      error: barber
        ? `${barber.name} already has something booked then. Pick another time, or resubmit with "force" to double-book anyway.`
        : "Every chair is already booked then. Pick another time, or resubmit with \"force\" to add it anyway.",
    });
  }

  const confirmation_code = generateConfirmationCode();
  const result = db
    .prepare(
      `INSERT INTO bookings
        (confirmation_code, customer_name, customer_phone, customer_email, service_id, barber_id, date, time, duration_minutes, notes, status, source)
       VALUES
        (@confirmation_code, @customer_name, @customer_phone, @customer_email, @service_id, @barber_id, @date, @time, @duration_minutes, @notes, 'confirmed', @source)`
    )
    .run({
      confirmation_code,
      customer_name: customer_name.trim(),
      customer_phone: customer_phone.trim(),
      customer_email: customer_email ? customer_email.trim() : null,
      service_id: service.id,
      barber_id: barber ? barber.id : null,
      date,
      time,
      duration_minutes: service.duration_minutes,
      notes: notes ? String(notes).slice(0, 1000) : null,
      source: source || "phone",
    });

  res.status(201).json({ ok: true, id: result.lastInsertRowid, confirmation_code, wasOverbooked: !isOpen });
});

// GET /api/admin/bookings?date=&status=
router.get("/bookings", (req, res) => {
  const { date, status } = req.query;
  let sql = `
    SELECT b.*, s.name AS service_name, br.name AS barber_name
    FROM bookings b
    JOIN services s ON s.id = b.service_id
    LEFT JOIN barbers br ON br.id = b.barber_id
    WHERE 1=1
  `;
  const params = [];
  if (date) {
    sql += " AND b.date = ?";
    params.push(date);
  }
  if (status) {
    sql += " AND b.status = ?";
    params.push(status);
  }
  sql += " ORDER BY b.date ASC, b.time ASC";

  res.json(db.prepare(sql).all(...params));
});

// PATCH /api/admin/bookings/:id  { status }
router.patch("/bookings/:id", (req, res) => {
  const { status } = req.body || {};
  const allowed = ["pending", "confirmed", "completed", "cancelled", "no_show"];
  if (!allowed.includes(status)) return res.status(400).json({ error: "Invalid status" });

  const result = db.prepare("UPDATE bookings SET status = ? WHERE id = ?").run(status, req.params.id);
  if (result.changes === 0) return res.status(404).json({ error: "Booking not found" });
  res.json({ ok: true });
});

// GET /api/admin/leads
router.get("/leads", (req, res) => {
  res.json(db.prepare("SELECT * FROM leads ORDER BY created_at DESC").all());
});

// PATCH /api/admin/leads/:id  { status }
router.patch("/leads/:id", (req, res) => {
  const { status } = req.body || {};
  const allowed = ["new", "contacted", "converted", "closed"];
  if (!allowed.includes(status)) return res.status(400).json({ error: "Invalid status" });

  const result = db.prepare("UPDATE leads SET status = ? WHERE id = ?").run(status, req.params.id);
  if (result.changes === 0) return res.status(404).json({ error: "Lead not found" });
  res.json({ ok: true });
});

module.exports = router;
