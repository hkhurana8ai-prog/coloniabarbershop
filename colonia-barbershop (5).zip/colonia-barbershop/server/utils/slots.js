// server/utils/slots.js
const db = require("../db");

const SLOT_STEP_MINUTES = 15;

function toMinutes(hhmm) {
  const [h, m] = hhmm.split(":").map(Number);
  return h * 60 + m;
}
function toHHMM(mins) {
  const h = Math.floor(mins / 60).toString().padStart(2, "0");
  const m = (mins % 60).toString().padStart(2, "0");
  return `${h}:${m}`;
}

/**
 * Returns an array of "HH:MM" strings that are bookable for the given date
 * and service duration.
 *
 * Capacity model: the shop has N active barbers ("chairs"). A booking either
 * pins a specific barber (barber_id set — used for admin/phone bookings made
 * for a regular who asked for someone by name) or floats unassigned
 * (barber_id null — what the public widget always creates, since customers
 * no longer pick a barber). A new slot is available when there's still at
 * least one chair free once you account for both: barbers individually
 * pinned by name, and the running count of unassigned bookings competing
 * for whatever's left. This is what actually answers "can a 6th person book
 * 4 PM" — yes, as long as fewer than 6 people (pinned + unassigned) already
 * overlap that slot.
 */
function getAvailableSlots({ date, durationMinutes, barberId = null }) {
  const dow = new Date(date + "T00:00:00").getDay();
  const hoursRow = db.prepare("SELECT * FROM business_hours WHERE day_of_week = ?").get(dow);
  if (!hoursRow || !hoursRow.open_time || !hoursRow.close_time) return [];

  const activeBarbers = db.prepare("SELECT * FROM barbers WHERE active = 1 ORDER BY sort_order").all();
  const totalChairs = activeBarbers.length;
  if (totalChairs === 0) return [];

  if (barberId && !activeBarbers.some((b) => b.id === Number(barberId))) return [];

  // Whole-shop closure for the date (holidays etc.)
  const shopClosed = db
    .prepare("SELECT 1 FROM time_off WHERE barber_id IS NULL AND date = ? AND start_time IS NULL")
    .get(date);
  if (shopClosed) return [];

  const openMin = toMinutes(hoursRow.open_time);
  const closeMin = toMinutes(hoursRow.close_time);

  const existingBookings = db
    .prepare(
      `SELECT barber_id, time, duration_minutes FROM bookings
       WHERE date = ? AND status NOT IN ('cancelled', 'no_show')`
    )
    .all(date);

  const timeOffRows = db
    .prepare(`SELECT barber_id, start_time, end_time FROM time_off WHERE date = ? AND barber_id IS NOT NULL`)
    .all(date);

  function overlaps(aStart, aEnd, bStart, bEnd) {
    return aStart < bEnd && bStart < aEnd;
  }

  // Is a specific barber free for [slotStart, slotStart+duration)? Used both
  // for "I want this exact barber" requests and to figure out how many
  // chairs are individually pinned at a given moment.
  function isBarberPinnedBusy(barber, slotStart, slotEnd) {
    for (const b of existingBookings) {
      if (b.barber_id !== barber.id) continue;
      const bStart = toMinutes(b.time);
      const bEnd = bStart + b.duration_minutes;
      if (overlaps(slotStart, slotEnd, bStart, bEnd)) return true;
    }
    for (const t of timeOffRows) {
      if (t.barber_id !== barber.id) continue;
      const tStart = t.start_time ? toMinutes(t.start_time) : openMin;
      const tEnd = t.end_time ? toMinutes(t.end_time) : closeMin;
      if (overlaps(slotStart, slotEnd, tStart, tEnd)) return true;
    }
    return false;
  }

  function isSlotAvailable(slotStart, slotEnd) {
    if (barberId) {
      const barber = activeBarbers.find((b) => b.id === Number(barberId));
      return !isBarberPinnedBusy(barber, slotStart, slotEnd);
    }

    // "No preference": count chairs already spoken for — both barbers
    // individually pinned for an overlapping time, and unassigned bookings
    // competing for the remaining chairs (plus anyone on time off).
    const pinnedBusyCount = activeBarbers.filter((b) => isBarberPinnedBusy(b, slotStart, slotEnd)).length;

    const unassignedOverlapCount = existingBookings.filter((b) => {
      if (b.barber_id !== null) return false;
      const bStart = toMinutes(b.time);
      const bEnd = bStart + b.duration_minutes;
      return overlaps(slotStart, slotEnd, bStart, bEnd);
    }).length;

    return pinnedBusyCount + unassignedOverlapCount < totalChairs;
  }

  const slots = [];
  for (let t = openMin; t + durationMinutes <= closeMin; t += SLOT_STEP_MINUTES) {
    if (isSlotAvailable(t, t + durationMinutes)) slots.push(toHHMM(t));
  }
  return slots;
}

module.exports = { getAvailableSlots, toMinutes, toHHMM };
