// server/utils/confirmationCode.js
const crypto = require("crypto");

function generateConfirmationCode() {
  return crypto.randomBytes(3).toString("hex").toUpperCase(); // e.g. "4F2A9C"
}

module.exports = { generateConfirmationCode };
